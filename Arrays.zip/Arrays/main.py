""" Import the modules that are necessary for arrays."""
from array import *

# Create an Array and Traverse.
my_array = array("i", [1,2,3,4,5])
for item in my_array:
    print(item, end="")
print()
# Accessing the individual elements through the indexes.
print("Accessing via Index")
print(my_array[3])
# Add new element using append() method.
print("Append functionality")
my_array.append(6)
print(my_array)
# Add new element using insert method.
print("Insert functionality")
my_array.insert(0, 11)
print(my_array)
# Extend the python array using extend method.
print("Extend functionality")
new_array = [11,12,13,14,15]
my_array.extend(new_array)
print(my_array)
# Add items from the list into arrays using fromlist method.
mylist = [21,22,23]
my_array.fromlist(mylist)
print(my_array)
# Remove any element from array using remove method.
my_array.remove(11)
print(my_array)
# Remove last element using pop method.
my_array.pop()
print(my_array)
# Fetch any element using Index method.
print(my_array.index(4))
# Reverse a python array using reverse method.
my_array.reverse()
print(my_array)
# Get array buffer info using buffer_info method.
print(my_array.buffer_info())
# Check the number of occurrences using count method.
my_array.append(11)
print(my_array.count(11))
# Convert an array to string using to_string method.
#my_string = my_array.tostring()
#print(my_string)
# Convert an array to list using to_list method.
my_list = my_array.tolist()
print(my_list)
print(type(my_list))

# Slice elements of an array.
print(my_array)
print(my_array[:5])
print(my_array[5:])